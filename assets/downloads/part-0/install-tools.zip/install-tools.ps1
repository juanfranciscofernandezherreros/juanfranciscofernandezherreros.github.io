# Argo CD real-world microservices - "Before You Begin" tool installer
#
# Installs: Git, Docker Desktop, kind, Java 21 (Temurin), Maven 3.9.16, ArgoCD CLI.
# kubectl is not installed separately - it ships with Docker Desktop.
#
# Usage:
#   1. Open PowerShell as a regular user (some steps will trigger a UAC
#      elevation prompt for Docker Desktop / Git / Java - accept it when asked).
#   2. Run:  powershell -ExecutionPolicy Bypass -File install-tools.ps1
#   3. After it finishes, open a NEW PowerShell window (PATH only refreshes
#      in new terminals) and verify with:
#        git --version
#        docker --version
#        kind version
#        kubectl version --client
#        java -version
#        mvn -version
#        argocd version --client
#
# Source: https://juanfranciscofernandezherreros.github.io/argo-real-world-microservices/part-0/before-you-begin/

$ErrorActionPreference = 'Continue'

function Run-Step {
    param(
        [string]$Description,
        [scriptblock]$Command
    )
    Write-Host ""
    Write-Host "===== $Description =====" -ForegroundColor Cyan
    try {
        & $Command
    } catch {
        Write-Host "ERROR: $_" -ForegroundColor Red
    }
    Start-Sleep -Seconds 2
}

Write-Host "Instalacion de herramientas - Argo CD real-world microservices" -ForegroundColor Yellow
Start-Sleep -Seconds 2

Run-Step "winget install Git.Git" {
    winget install --id Git.Git -e --accept-source-agreements --accept-package-agreements
}

Run-Step "winget install Docker.DockerDesktop" {
    winget install --id Docker.DockerDesktop -e --accept-source-agreements --accept-package-agreements
}

Run-Step "winget install Kubernetes.kind" {
    winget install --id Kubernetes.kind -e --accept-source-agreements --accept-package-agreements
}

Run-Step "winget install EclipseAdoptium.Temurin.21.JDK" {
    winget install --id EclipseAdoptium.Temurin.21.JDK -e --accept-source-agreements --accept-package-agreements
}

Run-Step "Descargar Maven 3.9.16" {
    Invoke-WebRequest -Uri "https://dlcdn.apache.org/maven/maven-3/3.9.16/binaries/apache-maven-3.9.16-bin.zip" -OutFile "$env:TEMP\apache-maven-3.9.16-bin.zip"
}

Run-Step "Verificar hash SHA512 de Maven" {
    Get-FileHash "$env:TEMP\apache-maven-3.9.16-bin.zip" -Algorithm SHA512
}

Run-Step "Expandir Maven en LOCALAPPDATA\Programs" {
    Expand-Archive -Path "$env:TEMP\apache-maven-3.9.16-bin.zip" -DestinationPath "$env:LOCALAPPDATA\Programs" -Force
}

Run-Step "Configurar MAVEN_HOME" {
    [Environment]::SetEnvironmentVariable("MAVEN_HOME", "$env:LOCALAPPDATA\Programs\apache-maven-3.9.16", "User")
}

Run-Step "Anadir Maven al PATH de usuario" {
    $current = [Environment]::GetEnvironmentVariable("Path", "User")
    if ($current -notlike "*apache-maven-3.9.16*") {
        [Environment]::SetEnvironmentVariable("Path", "$current;$env:LOCALAPPDATA\Programs\apache-maven-3.9.16\bin", "User")
    }
}

Run-Step "winget install argoproj.argocd" {
    winget install --id argoproj.argocd -e --accept-source-agreements --accept-package-agreements
}

Write-Host ""
Write-Host "===== INSTALACION COMPLETA =====" -ForegroundColor Green
Start-Sleep -Seconds 3
